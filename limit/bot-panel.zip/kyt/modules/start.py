from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline(" MENU ","menu")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val :

		msg = f"""
Hai, Saya adalah bot izz Store
Silahkan Ketik /menu atau klik Button Dibawah ini
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)




